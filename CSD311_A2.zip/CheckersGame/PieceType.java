package CheckersGame;

public enum PieceType {
   BLACK_REGULAR, //Normal Black
   BLACK_KING,  //King Black
   WHITE_REGULAR,  // Normal White
   WHITE_KING   //King White
}

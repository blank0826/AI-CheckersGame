package CheckersGame;

public class PieceLocation {
    public Pieces pieces; //piece in checker
    public int a; //current Location at A
    public int b; //current Location at B
    public boolean left; //checks if any piece in left to capture
    public boolean right; //checks if any piece in left to capture
}

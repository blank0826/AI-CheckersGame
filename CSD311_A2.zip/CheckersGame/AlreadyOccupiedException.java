package CheckersGame;

public class AlreadyOccupiedException extends RuntimeException
{
   public AlreadyOccupiedException(String exception)
   {
      super(exception);
   }
}

